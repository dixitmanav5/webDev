const express=require("express");
const app=express();
const hostname="127.0.0.1";
const port=3000;
//Express part
app.use("/static",express.static("static"));
//Pug part
app.set("view engine","pug");
app.set("views","/data/data/com.termux/files/home/express_prac/templateInheritense/dance_website/view");
app.get("/",(req,res)=>{
res.status(200).render("dance");
});
app.get("/contact",(req,res)=>{
res.status(200).render("contact");
});
//endpoints
app.listen(port,hostname,()=>{
console.log("app is running on "+hostname+":"+port);
});

