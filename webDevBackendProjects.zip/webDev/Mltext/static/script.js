let textBox=document.getElementById("textBox");
const socket=io('http://192.168.1.5:3001');
textBox.addEventListener('input',()=>{
let text=textBox.value;
socket.emit("textChange",text);
});
socket.on("changed",text=>{
textBox.innerHTML=text;
});
