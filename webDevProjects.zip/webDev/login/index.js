const webSocket=require("ws");
const cookieParser=require("cookie-parser");
const express=require("express");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const app=express();
const hostname="192.168.1.5";
const port=8000;
const port2=8080;
const key="iAmManavDixitOfClass9AIamAWebDeveloper";
const mongoose=require("mongoose");
mongoose.connect("mongodb://localhost/cloudlogin",{useNewUrlParser:true,useUnifiedTopology:true,useCreateIndex:true}).then(()=>{console.log("Connected SuccessFully")}).catch((e)=>{console.log(e)});
app.use("/stc",express.static("static"));
app.set("view engine","pug");
app.set("views","/webDev/login/view");
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());
let signupSchema=new mongoose.Schema({
	name:{
		type:String,
		required:String
	},
	age:{
		type:Number,
		required:true
	},
	gender:{
		type:String,
		required:true
	},
	email:{
		type:String,
		required:true,
		unique:true
	},
	number:{
		type:Number,
		required:true,
		unique:true
	},
	password:{
		type:String,
		required:true
	},
	confirmpassword:{
		type:String,
		required:true
	},
	tokens:{
		type:Array,
		required:true
	}
});
let register=mongoose.model("login",signupSchema);
app.get("/",auth,(req,res)=>{
console.log(req.verified);
if(req.verified==true){
register.findOne({email:req.user_info.email}).then((user_info)=>{
let user=user_info;
res.render("dance.pug");
}).catch((e)=>{
console.log(e);
});
}
else{
res.render("signup.pug");
console.log('not signed in');
}
});
app.post("/",(req,res)=>{
let password=req.body.password;
let cpassword=req.body.confirmpassword;
if(password === cpassword){
let Spassword=bcrypt.hashSync(password,10);
req.body.password=Spassword;
req.body.confirmpassword=Spassword;
let token=jwt.sign({email:req.body.email},key);
let data=new register({
	name:req.body.name,
	age:req.body.age,
	gender:req.body.gender,
        email:req.body.email,
	number:req.body.number,
        password:Spassword,
	confirmpassword:Spassword
});
data.tokens.push({token:token});
data.save().then(()=>{
	res.cookie("login",token,()=>{
		expires:new Date(Date.now()+50000);
		httpOnly:true;//this will not aloow any client side scripting languageto edit this
	});
	res.redirect("/login");
}).catch(e=>{

	let err=String(e);
	if(err.includes("is required")){
		console.log(err);
		res.status(400).send("All columns must be filled");
	}
	else{
		console.log(err);
		res.status(400).send("This Email/Phone number is already taken");
	}

});
}
else{
res.status(400).send("Password dont match");
}
});
app.get("/login",auth,(req,res)=>{
console.log(req.verified);
console.log(req.user_info);
if(req.verified==true){
register.findOne({email:req.user_info[1]}).then((user_info)=>{
let user=user_info;
res.redirect("/");
console.log('redirected');
}).catch((e)=>{
console.log(e);
});
}
else{
res.render("login.pug");
console.log('not signed in');
}
});
app.post("/login",(req,res)=>{
	let input_email=req.body.email;
	register.findOne({email:input_email}).then((data)=>{
		let email=data.email;
		let password=data.password;
		let input_pass=req.body.password;
		if(email==null){
			res.send("Invalid Email")
		}
		else{
			bcrypt.compare(input_pass,password).then((data)=>{
				let ismatch=data;
				console.log(data);
				let token=jwt.sign({email:email},key);
				console.log(token);
			if(ismatch){
				console.log(data);
				res.cookie("login",token,()=>{
					httpOnly:true;
				})
				res.redirect("/");                                                           }                                               else{                                                   res.send("Wrong Password");                                                             }
			}).catch((e)=>{});
		}
	}).catch((e)=>{res.send("Invalid Email")});

});
app.get("/logout",(req,res)=>{
res.clearCookie("login");
res.redirect("/login");
});
function auth(req,res,next){
	let token=req.cookies.login;
	if(token!=undefined){
	let user_verified=jwt.verify(token,key);
	console.log(user_verified);
	req.verified=true;
	req.user_info=user_verified;
	}
	else{
	req.verified=false;
	}
	next();
}
app.listen(port,hostname,()=>{
console.log(`The app is running on ${hostname} : ${port}`);
});
