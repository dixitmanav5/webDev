const express=require("express");
const fs=require("fs");
const app=express();
const hostname="127.0.0.1";
const port=2000;
//Express part
app.use("/static",express.static("static"));
app.use(express.urlencoded({extended:true}));//When extended property is set to true, the URL-encoded data will be parsed with the qs library and when extended property is set to false, the URL-encoded data will instead be parsed with the querystring library.
/*qs library allows you to create a nested object from your query string*/
/*query-string library does not support creating a nested object from your query string.*/

//pug part
app.set("view engine","pug");                   app.set("views","/data/data/com.termux/files/home/express_prac/gymbackend/view");
//End points
app.get("/",(req,res)=>{
res.status(200).render("index");
});
app.post("/",(req,res)=>{
res.send("You are succesfully registered to our gym");
const info=req.body;
const name=info.name;
fs.writeFileSync(name+".json",JSON.stringify(info));
});
app.listen(port,hostname,()=>{
console.log("App is running on "+hostname+":"+port);
});
