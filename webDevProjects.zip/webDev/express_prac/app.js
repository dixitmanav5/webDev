const exp=require("express");
const app=exp();
const port=2000;
//get requsts
app.get("/",(req,res)=>{
res.send("This is Home Page of express app");
});
app.get("/about",(req,res)=>{
res.send("This is about page of express app");
});
app.get("/contact",(req,res)=>{
res.send("This is contact page of express app");
});
//sending status code
app.get("/services",(req,res)=>{
res.status(200).send("This is Services page of express app");
});
app.get("/man",(req,res)=>{
res.status(404).send("Page not found");
});
app.post("/services",(req,res)=>{               res.send("This is post request of services page of express app");                               });
//adding static files(that anyone can access)
app.use("/stc",exp.static("static"));//app.use("url",express.static("dirctory name"))
//Seting template engine as pug
app.set("view engine","pug");
//seting the pug (view) directory
app.set("views",'/data/data/com.termux/files/home/express_prac/view');//app.set("views","dorectory location/name
//endpoint of pug file
app.get("/pugdemo",(req,res)=>{
res.status(200).render('demo',{title:"Pug file made by Manav Dixit",massage:"hello there i am Manav Dixit"});//res.render OR res.status(status code).render("file name",{variables value});
});
//using raw html in pug
app.set("views","/data/data/com.termux/files/home/express_prac/view");//seting pug directory
//endpoint of pug file
app.get("/rawpug",(req,res)=>{
const cont="This is content created in html using pug in express in node js";
res.status(200).render("rawhtml",{"content":cont});
});
//listing at localhost on the given port
app.listen(port,()=>{
console.log("Express app is running on port "+port);
});
