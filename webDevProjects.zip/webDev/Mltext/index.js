const express=require('express');
const app=express();
const hostname='192.168.1.5';
const port='3000';
const server=require('http').createServer().listen(3001,hostname);
app.use(express.static('static'));
app.get('/',(req,res)=>{
res.sendFile('/webDev/Mltext/view/MlText.html');
});
const mySocket=require("socket.io")({
cors:{
origin:[`http://${hostname}:${port}`]
}
}).listen(server);
//Code for what to when a connection is made to socket
mySocket.on('connection',(socket)=>{
console.log('new connection');
//When a textChanged event had sent by client
socket.on('textChange',text=>{
//sending a event name changed when text is edited
socket.broadcast.emit('changed',text);
});
});
app.listen(port,hostname,()=>{
console.log(`Connected to ${hostname}:${port}`);
});
